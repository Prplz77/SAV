import { GoogleGenAI, Type } from "@google/genai";
import { CallSummary } from "../types";

// Always initialize GoogleGenAI using a named parameter with process.env.API_KEY directly.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Résumé rapide utilisant gemini-2.5-flash-lite pour une latence minimale.
 */
export const summarizeCall = async (
  rawNotes: string, 
  technicalDetails?: { productType: string; brand: string; gatewayReplaced: boolean }
): Promise<CallSummary> => {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-lite-latest',
    contents: `Tu es un expert SAV CVC. Marque: ${technicalDetails?.brand}, Produit: ${technicalDetails?.productType}.
    Résume ces notes au format JSON : ${rawNotes}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          subject: { type: Type.STRING },
          issue: { type: Type.STRING },
          solution: { type: Type.STRING },
          nextSteps: { type: Type.STRING },
          sentiment: { type: Type.STRING, enum: ["positive", "neutral", "negative"] }
        },
        required: ["subject", "issue", "solution", "nextSteps", "sentiment"]
      }
    }
  });

  return JSON.parse(response.text || '{}') as CallSummary;
};

/**
 * Analyse complexe utilisant gemini-3-pro-preview avec thinkingBudget pour les diagnostics difficiles.
 */
export const deepAnalyzeCall = async (
  rawNotes: string,
  technicalDetails: { brand: string; productType: string }
): Promise<CallSummary> => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `Analyse approfondie pour un diagnostic complexe SAV. 
    Marque: ${technicalDetails.brand}, Composant: ${technicalDetails.productType}.
    Notes: ${rawNotes}`,
    config: {
      thinkingConfig: { thinkingBudget: 32768 },
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          subject: { type: Type.STRING },
          issue: { type: Type.STRING, description: "Analyse détaillée des causes possibles" },
          solution: { type: Type.STRING, description: "Tests avancés recommandés" },
          nextSteps: { type: Type.STRING, description: "Préconisation technique finale" },
          sentiment: { type: Type.STRING, enum: ["positive", "neutral", "negative"] }
        },
        required: ["subject", "issue", "solution", "nextSteps", "sentiment"]
      }
    }
  });

  return JSON.parse(response.text || '{}') as CallSummary;
};
