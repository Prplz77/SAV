import React, { useRef, useState } from 'react';
import { View } from '../types';
import { 
  PhoneCall, History, LayoutDashboard, Headset, 
  Share2, UserCircle, Zap, Globe, ShieldCheck 
} from 'lucide-react';

interface LayoutProps {
  children: React.ReactNode;
  currentView: View;
  setView: (view: View) => void;
  onExport: () => void;
  onImport: (data: string) => void;
  technician: string;
  setTechnician: (name: string) => void;
}

export const Layout: React.FC<LayoutProps> = ({ 
  children, currentView, setView, onExport, onImport, technician, setTechnician 
}) => {
  const [showSync, setShowSync] = useState(false);
  const [tempCode, setTempCode] = useState('');

  const handleSync = () => {
    try {
      const decoded = atob(tempCode);
      onImport(decoded);
      setTempCode('');
      setShowSync(false);
      alert("Base de données synchronisée avec succès !");
    } catch (e) {
      alert("Code de synchronisation invalide.");
    }
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-[#f1f5f9]">
      {/* Sidebar Latérale */}
      <nav className="w-full md:w-80 bg-slate-900 text-white p-8 flex flex-col sticky top-0 md:h-screen shadow-2xl z-50">
        <div className="flex items-center gap-4 mb-10">
          <div className="bg-blue-600 p-3 rounded-2xl shadow-lg shadow-blue-500/20">
            <Headset size={28} className="text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight leading-none uppercase">SAV ASSIST</h1>
            <div className="flex items-center gap-2 mt-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">En ligne - Cloud Ready</p>
            </div>
          </div>
        </div>

        {/* Profil Utilisateur (Sauvegarde l'historique de chacun) */}
        <div className="mb-8 p-5 bg-slate-800/40 rounded-2xl border border-white/5">
          <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-3 block">Identifiant Technicien</label>
          <div className="relative">
            <UserCircle className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
              type="text" 
              value={technician}
              onChange={(e) => setTechnician(e.target.value)}
              placeholder="Votre nom..."
              className="w-full bg-slate-900/50 border border-slate-700 rounded-xl py-2.5 pl-10 pr-4 text-sm font-bold focus:border-blue-500 outline-none transition-all placeholder:text-slate-600"
            />
          </div>
        </div>

        <div className="flex flex-col gap-2 flex-grow">
          <button
            onClick={() => setView('new-call')}
            className={`flex items-center gap-4 px-5 py-4 rounded-2xl transition-all group ${
              currentView === 'new-call' ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <PhoneCall size={20} />
            <span className="font-bold">Nouvel Appel</span>
          </button>
          
          <button
            onClick={() => setView('history')}
            className={`flex items-center gap-4 px-5 py-4 rounded-2xl transition-all group ${
              currentView === 'history' ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <History size={20} />
            <span className="font-bold">Historique Partagé</span>
          </button>

          <button
            onClick={() => setView('stats')}
            className={`flex items-center gap-4 px-5 py-4 rounded-2xl transition-all group ${
              currentView === 'stats' ? 'bg-blue-600 text-white shadow-xl shadow-blue-500/20' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            <LayoutDashboard size={20} />
            <span className="font-bold">Performances</span>
          </button>
        </div>

        {/* Section Synchronisation Équipe */}
        <div className="mt-auto pt-6 border-t border-slate-800 space-y-4">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center gap-2">
            <Share2 size={12} /> Réseau & Synchronisation
          </p>
          <div className="grid grid-cols-2 gap-2">
            <button 
              onClick={onExport}
              className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors border border-slate-700 group"
            >
              <Zap size={16} className="text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="text-[9px] font-bold">Générer Code</span>
            </button>
            <button 
              onClick={() => setShowSync(true)}
              className="flex flex-col items-center justify-center gap-2 p-3 rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors border border-slate-700 group"
            >
              <Globe size={16} className="text-blue-400 group-hover:scale-110 transition-transform" />
              <span className="text-[9px] font-bold">Synchroniser</span>
            </button>
          </div>
          <div className="flex items-center gap-2 px-3 py-2 bg-emerald-500/10 border border-emerald-500/20 rounded-xl">
            <ShieldCheck size={14} className="text-emerald-500" />
            <span className="text-[10px] text-emerald-500 font-bold uppercase tracking-tighter">Données locales sécurisées</span>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-grow p-6 md:p-12 overflow-y-auto h-screen">
        <div className="max-w-[1500px] mx-auto">
          {children}
        </div>
      </main>

      {/* Modal de Synchronisation */}
      {showSync && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <div className="bg-white rounded-[2.5rem] p-10 w-full max-w-lg shadow-2xl animate-in zoom-in-95 duration-300">
            <div className="flex items-center gap-4 mb-6">
              <div className="bg-blue-100 p-3 rounded-2xl text-blue-600">
                <Globe size={24} />
              </div>
              <div>
                <h3 className="text-2xl font-black text-slate-900">Sync Collective</h3>
                <p className="text-slate-500 text-sm">Fusionnez l'historique d'un collègue via son code.</p>
              </div>
            </div>
            
            <textarea 
              value={tempCode}
              onChange={(e) => setTempCode(e.target.value)}
              placeholder="Collez ici le code envoyé par votre collègue..."
              className="w-full h-40 p-6 bg-slate-50 border-2 border-slate-100 rounded-[1.5rem] mb-8 outline-none focus:border-blue-500 font-mono text-[10px] break-all text-slate-400"
            />
            
            <div className="flex gap-4">
              <button onClick={() => setShowSync(false)} className="flex-1 py-4 font-bold text-slate-500 hover:bg-slate-100 rounded-2xl transition-all">Annuler</button>
              <button onClick={handleSync} className="flex-1 py-4 bg-blue-600 text-white font-black rounded-2xl shadow-xl shadow-blue-500/20 hover:bg-blue-700 active:scale-95 transition-all">Fusionner Historiques</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
